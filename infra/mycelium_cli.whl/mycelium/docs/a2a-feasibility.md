# A2A Feasibility Review

Architecture review: could Mycelium's HTTP REST connected flows use the
[Agent2Agent (A2A) Protocol](https://a2a-protocol.org/v1.0.0/specification/) instead?

**Date:** 2026-06-12  
**Status:** Exploratory / not a commitment to implement

---

## What A2A is (relevant bits)

A2A is an **agent-to-agent interoperability** standard (Linux Foundation, v1.0.0).
It is designed for:

- **Discovery** — `GET /.well-known/agent-card.json` (skills, auth, supported bindings)
- **Task delegation** — client agent sends work to a remote agent; remote returns a
  **Task** with a stateful lifecycle
- **Messaging** — `SendMessage` / `SendStreamingMessage` with **Message**, **Part**,
  **Artifact**
- **Transport** — HTTPS; bindings include **JSON-RPC + SSE**, **gRPC**, and
  **HTTP/REST** (`POST /message:send`, `POST /message:stream`, `GET /tasks/{id}`, etc.)

A2A explicitly **complements MCP** (agent↔tool). It is **not** a room bus, memory
store, or multi-agent negotiation engine. Agents are opaque peers; callers do not
see each other's internal state.

See also: [What is A2A?](https://a2a-protocol.org/dev/) and the
[A2A vs MCP](https://a2a-protocol.org/dev/) positioning (tools vs agents).

---

## Mycelium's HTTP flows today

| Flow | Client | Server | Pattern | What moves |
|------|--------|--------|---------|------------|
| **Hub ↔ spoke (CLI/adapters)** | Spoke CLI, OpenClaw/Hermes plugin | Hub FastAPI `:8000` | REST + **SSE** | Rooms, memory, session join, negotiate propose/respond, room messages |
| **Room realtime** | Plugins, UI, `mycelium watch` | Backend | **SSE** (`/rooms/{room}/messages/stream`) via Postgres NOTIFY | `coordination_tick`, `coordination_consensus`, broadcasts |
| **Agent → room** | Plugin | Backend | **POST** `/api/rooms/{room}/messages` | Agent replies, structured negotiation payloads |
| **Backend ↔ IOC/CFN** | `mycelium-backend` | `ioc-cfn-mgmt-plane-svc:9000`, `ioc-cognition-fabric-node-svc:9002` | **REST** (generated OpenAPI client) | MAS provisioning, semantic negotiation start/decide, knowledge graph |
| **Backend ↔ DB** | Backend | `mycelium-db` | **PostgreSQL** | Rooms, messages, memories, sessions |
| **Metrics** | OpenClaw, spoke collector | Hub collector `:4318` | **HTTP OTLP** | Traces/metrics (orthogonal to A2A) |

**Key code paths:**

- Room messages + coordination hook: `fastapi-backend/app/routes/messages.py`
- SSE streams: `fastapi-backend/app/routes/stream.py`
- CFN negotiation: `fastapi-backend/app/services/cfn_negotiation.py`,
  `fastapi-backend/app/services/coordination.py`
- CLI negotiate: `mycelium-cli/src/mycelium/commands/negotiate.py`
- OpenClaw routing (ticks, consensus): `mycelium-cli/.../openclaw/.../plugin/src/channel/route.ts`

Architecturally, Mycelium is a **shared coordination plane** (rooms, memory,
CognitiveEngine, CFN-backed negotiation) with agents as **clients of that plane**.
A2A assumes agents are **servers** (or peers) that expose tasks to each other.

That is the core mismatch.

---

## Flow-by-flow: could A2A replace this?

### 1. Hub ↔ spoke (CLI + plugins) — partially, awkwardly

**Today:** spoke POSTs messages and subscribes to hub SSE; hub fans out ticks and
consensus.

**A2A analogue:** each agent runs an **A2A server**; peers use
`SendStreamingMessage` to each other.

**Problems:**

- Spokes do not expose stable HTTPS agent endpoints today — OpenClaw/Hermes
  gateways are local processes.
- Coordination is **mediated** (CognitiveEngine + CFN decide rounds), not bilateral
  task delegation.
- Hub holds **authoritative state** (rooms, plans, memory). A2A has no room/plan/memory
  model.
- You would still need the hub for persistence, CFN, and multi-agent semantics.

**Possible hybrid:** hub (or each spoke gateway) exposes an **A2A façade** that
maps `Task` ↔ “join this room / respond to this tick.” That is an **adapter layer**,
not a replacement for the REST API.

### 2. Structured negotiation — poor fit

Mycelium negotiation is domain-specific:

- `issue_options`, `can_counter_offer`, `prior_round_outcome`
- CFN `semantic-negotiation/start` + `decide`
- Session sub-rooms, round budgets, plan compilation

A2A tasks are **generic** (input → processing → artifacts). There is no standard for
“multi-issue bargaining with a standing offer.” You would encode all of that in custom
**Part** metadata or extensions — effectively reinventing SSTP inside A2A.

**Verdict:** keep Mycelium/CFN negotiation; do not force it into A2A unless we publish
an **A2A Extension** for structured multi-agent negotiation (heavy lift, limited ecosystem
benefit today).

### 3. Backend ↔ IOC/CFN containers — no

These are **Outshift CFN HTTP APIs** on the internal Docker network. A2A does not apply
unless CFN ships an A2A binding (they do not today). Replacing this with A2A would
require CFN to change, not Mycelium.

### 4. Room chat / memory / plans — no

REST CRUD + filesystem-native memory + plan APIs are **application data**, not agent
delegation. A2A does not model shared team memory or markdown room files.

### 5. Real-time SSE — conceptually similar, not drop-in

A2A v1.0 uses **SSE for streaming** (`SendStreamingMessage`, `SubscribeToTask`) —
same transport family as Mycelium's room stream. Event shapes differ:

| Mycelium SSE | A2A stream |
|--------------|------------|
| `coordination_tick`, `coordination_consensus`, room broadcasts | `TaskStatusUpdateEvent`, `TaskArtifactUpdateEvent`, or direct `Message` |
| Fan-out via hub NOTIFY | Point-to-point task subscription |

You could wrap hub SSE behind A2A streaming at the boundary, but you would not remove
the hub stream — you would **translate** it.

### 6. Metrics (OTLP) — N/A

Different problem (observability). A2A does not replace OTLP.

---

## Where A2A could add value

| Use case | Approach |
|----------|----------|
| **External agents join a Mycelium room** | Hub or gateway exposes A2A server; foreign agents discover via AgentCard and receive tasks like “participate in negotiation X.” |
| **Spoke agent as A2A client to third-party agents** | Mycelium adapter delegates subtasks via `SendMessage` to non-Mycelium agents and posts results back to the room. |
| **Federation across teams** | Team A's hub exposes A2A; Team B's agents delegate without bespoke REST integration. |
| **Standardized agent discovery** | Publish AgentCard per registered handle (`skills: ["mycelium.negotiate", "mycelium.memory.read"]`) instead of ad hoc config. |

That is **“A2A at the edge”** — interoperability with the outside world — not
replacing internal REST.

---

## Could we use A2A's HTTP/REST binding instead of our REST API?

Technically yes at the **syntax** level (both are HTTPS + JSON). Practically **no** as
a straight swap:

- Mycelium API is **OpenAPI resource-oriented** (`/rooms`, `/sessions`, `/messages`).
- A2A REST is **operation-oriented** (`POST /message:send`, `GET /tasks/{id}`) with a
  fixed task/message model.
- Every CLI command, plugin, frontend route, and OpenAPI client would need rewriting.
- You would lose first-class rooms/memory unless you bolt them on as custom extensions.

Migrating would mean adopting a **different application protocol**, not gaining transport
efficiency.

---

## Recommendation

| Layer | Keep REST / current | Consider A2A |
|-------|---------------------|--------------|
| Hub backend (rooms, memory, plans, CFN orchestration) | ✓ | Only as optional gateway |
| CFN/IOC integration | ✓ | ✗ |
| CLI | ✓ | ✗ |
| OpenClaw/Hermes plugin ↔ hub | ✓ (or keep SSE) | Optional second binding |
| **Interoperability with external A2A agents** | — | ✓ new feature |
| **Cross-vendor agent delegation** | — | ✓ adapter pattern |

**Bottom line:** A2A is feasible as an **optional interoperability surface** (“foreign
agents can talk to Mycelium”), not as a replacement for Mycelium's internal REST + SSE +
CFN stack. The hub-and-spoke model (shared backend as source of truth) and CFN-mediated
negotiation are **orthogonal** to A2A's peer task-delegation model.

---

## Suggested spike (lowest risk)

If we want to validate A2A without touching CFN, memory, or the CLI:

1. Expose `/.well-known/agent-card.json` on the hub (or per registered agent via gateway).
2. Implement `SendStreamingMessage` → translate to `POST /rooms/{room}/messages` +
   subscribe to session SSE.
3. Map A2A `Task` states to coordination session lifecycle (`negotiating` → `completed`).

That proves external A2A clients can participate in a Mycelium room without rewriting
the coordination plane.

---

## References

- [A2A Protocol Specification v1.0.0](https://a2a-protocol.org/v1.0.0/specification/)
- [A2A GitHub (a2aproject/A2A)](https://github.com/a2aproject/A2A)
- [Hub & Spoke Setup](guides/hub-and-spoke.md) — Mycelium transport model (HTTPS/SSE)
- [Architecture](architecture.md) — deployment modes and stack overview
