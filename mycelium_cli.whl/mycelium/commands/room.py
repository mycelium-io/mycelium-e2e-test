# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Mycelium Contributors

"""
Room management commands for Mycelium CLI.

Commands:
- (default): Show current active room
- ls: List rooms
- create: Create a new room
- use: Switch active room context
- delete: Delete a room
- join: Join coordination backchannel (blocks until first coordination tick)
- watch: Stream messages from a room via SSE
- post: Post a message to a room
- delegate: Delegate a task to an agent in a room
- clone: Clone a room from a remote backend instance
- sync-mas: Register (or re-register) a room with the CFN mgmt plane
"""

import json as json_module
import os

import typer

from mycelium.config import MyceliumConfig
from mycelium.doc_ref import doc_ref
from mycelium.error_handler import print_error
from mycelium.exceptions import ConfigNotFoundError, MyceliumError


def _typed_client(config: MyceliumConfig):
    """Get a typed OpenAPI client."""
    from mycelium_backend_client import Client

    return Client(base_url=config.server.api_url, raise_on_unexpected_status=True)


app = typer.Typer(
    help="Shared spaces for agent coordination. Rooms are persistent namespaces for memory and coordination. Spawn sessions within rooms for real-time negotiation.",
    invoke_without_command=True,
)


@app.callback(invoke_without_command=True)
def room_main(ctx: typer.Context) -> None:
    """Show current active room or manage rooms."""
    if ctx.invoked_subcommand is not None:
        return

    try:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False  # noqa: F841
        json_output = ctx.obj.get("json", False) if ctx.obj else False

        config = MyceliumConfig.load()
        active_room = config.get_active_room()

        if not active_room:
            if json_output:
                typer.echo(json_module.dumps({"active_room": None}))
            else:
                typer.secho("No active room set.", fg=typer.colors.YELLOW)
                typer.echo("Set a room with: mycelium room use <name>")
            raise typer.Exit(1)

        from mycelium_backend_client.api.rooms import list_rooms_api_rooms_get as list_api
        from mycelium_backend_client.models import HTTPValidationError

        with _typed_client(config) as client:
            result = list_api.sync(client=client, name=active_room, limit=1)
            rooms_data = (
                [r.to_dict() for r in result]
                if result and not isinstance(result, HTTPValidationError)
                else []
            )

        if not rooms_data:
            typer.secho(f"Active room '{active_room}' not found on server.", fg=typer.colors.RED)
            raise typer.Exit(1)

        room = rooms_data[0]
        if json_output:
            typer.echo(json_module.dumps(room, indent=2, default=str))
        else:
            typer.secho(f"Current Room: {room['name']}", fg=typer.colors.GREEN, bold=True)
            typer.echo(f"  ID:      {room.get('id')}")
            typer.echo(f"  Created: {str(room.get('created_at', ''))[:10]}")

    except Exception as e:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False
        print_error(e, verbose=verbose)


@doc_ref(
    usage="mycelium room ls",
    desc="List all rooms with state and member count.",
    group="room",
)
@app.command("ls")
def list_rooms(
    ctx: typer.Context,
    limit: int = typer.Option(20, "--limit", "-l"),
    name: str | None = typer.Option(None, "--name", "-n"),
) -> None:
    """List available rooms."""
    try:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False  # noqa: F841
        json_output = ctx.obj.get("json", False) if ctx.obj else False

        config_path = MyceliumConfig.get_config_path()
        if not config_path.exists():
            raise ConfigNotFoundError(str(config_path))

        config = MyceliumConfig.load()

        params: dict[str, str | int] = {"limit": limit}
        if name:
            params["name"] = name

        from mycelium_backend_client.api.rooms import list_rooms_api_rooms_get as list_api
        from mycelium_backend_client.models import HTTPValidationError

        with _typed_client(config) as client:
            result = list_api.sync(client=client, name=name, limit=limit)
            rooms_data = (
                [r.to_dict() for r in result]
                if result and not isinstance(result, HTTPValidationError)
                else []
            )

        if json_output:
            typer.echo(json_module.dumps(rooms_data, indent=2, default=str))
        else:
            if not rooms_data:
                typer.echo("No rooms found.")
                typer.echo("Create a room with: mycelium room create <name>")
                return

            active_room = config.get_active_room()
            typer.secho(f"Rooms ({len(rooms_data)})", bold=True)
            typer.echo("")

            for room in rooms_data:
                is_active = room["name"] == active_room
                created_at = str(room.get("created_at", ""))[:10]
                if is_active:
                    typer.secho(f"  * {room['name']}", fg=typer.colors.GREEN, bold=True, nl=False)
                    typer.echo(f"  (created {created_at})")
                else:
                    typer.echo(f"    {room['name']}  (created {created_at})")

            typer.echo("")
            typer.echo("Use 'mycelium room use <name>' to set the active room")

    except Exception as e:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False
        print_error(e, verbose=verbose)


@doc_ref(
    usage="mycelium room create <name>",
    desc="Create a new persistent coordination room.",
    group="room",
)
@app.command()
def create(
    ctx: typer.Context,
    name: str | None = typer.Argument(None, help="Room name"),
    public: bool = typer.Option(True, "--public/--private"),
) -> None:
    """Create a new room."""
    try:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False  # noqa: F841
        json_output = ctx.obj.get("json", False) if ctx.obj else False

        config_path = MyceliumConfig.get_config_path()
        if not config_path.exists():
            raise ConfigNotFoundError(str(config_path))

        config = MyceliumConfig.load()

        if name is None:
            name = typer.prompt("Room name")

        from mycelium_backend_client.api.rooms import create_room_api_rooms_post as create_api
        from mycelium_backend_client.models import RoomCreate

        with _typed_client(config) as client:
            body = RoomCreate(
                name=name,
                is_public=public,
            )
            result = create_api.sync(client=client, body=body)
            room_data = result.to_dict() if result and hasattr(result, "to_dict") else {}

        # The backend now creates the directory, but also create locally
        # in case the CLI is running on a different machine
        from mycelium.filesystem import ensure_room_structure, get_room_dir

        room_dir = get_room_dir(name)
        ensure_room_structure(room_dir)

        if json_output:
            typer.echo(json_module.dumps(room_data, indent=2, default=str))
        else:
            typer.secho(
                f"Created room: {room_data['name']}",
                fg=typer.colors.GREEN,
            )
            typer.echo(f"  ID:      {room_data.get('id')}")
            typer.echo(f"  Created: {str(room_data.get('created_at', ''))[:10]}")
            typer.echo(f"  Path:    {room_dir}")
            if room_data.get("mas_id"):
                typer.echo(f"  MAS ID:  {room_data.get('mas_id')}")
            typer.echo("")
            typer.echo(f"  Run 'mycelium room use {name}' to make it your active room")

    except Exception as e:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False
        print_error(e, verbose=verbose)


@doc_ref(
    usage="mycelium room use <name>",
    desc="Switch active room. Subsequent <code>memory</code> and <code>message</code> commands use this room by default.",
    group="room",
)
@app.command("use")
def use(
    ctx: typer.Context,
    room_name: str = typer.Argument(..., help="Room name to set as active"),
) -> None:
    """Switch active room for this project."""
    try:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False  # noqa: F841
        json_output = ctx.obj.get("json", False) if ctx.obj else False

        config = MyceliumConfig.load()

        from mycelium_backend_client.api.rooms import list_rooms_api_rooms_get as list_api
        from mycelium_backend_client.models import HTTPValidationError

        with _typed_client(config) as client:
            result = list_api.sync(client=client, name=room_name, limit=1)
            rooms_data = (
                [r.to_dict() for r in result]
                if result and not isinstance(result, HTTPValidationError)
                else []
            )

            if not rooms_data:
                raise MyceliumError(
                    f"Room '{room_name}' not found",
                    suggestion=f"Create it first with: mycelium room create {room_name}",
                )

        config.init_project(room_name=room_name)
        config.save()

        if json_output:
            typer.echo(json_module.dumps({"room": room_name}))
        else:
            typer.secho(f"Room set: {room_name}", fg=typer.colors.GREEN)
            typer.echo(
                "Next: Run 'mycelium session join -H <handle> -m <position>' to start negotiating"
            )

    except Exception as e:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False
        print_error(e, verbose=verbose)


@doc_ref(
    usage="mycelium room delete <name> [--force]",
    desc="Delete a room and all its data (memories, sessions, messages).",
    group="room",
)
@app.command()
def delete(
    ctx: typer.Context,
    room_name: str = typer.Argument(..., help="Room name to delete"),
    force: bool = typer.Option(False, "--force", "-f"),
) -> None:
    """Delete a room."""
    try:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False  # noqa: F841
        config_path = MyceliumConfig.get_config_path()
        if not config_path.exists():
            raise ConfigNotFoundError(str(config_path))

        config = MyceliumConfig.load()

        if not force:
            confirm = typer.confirm(f"Delete room '{room_name}'? This cannot be undone.")
            if not confirm:
                typer.echo("Cancelled.")
                raise typer.Exit(0)

        from mycelium_backend_client.api.rooms import (
            delete_room_api_rooms_room_name_delete as delete_api,
        )

        with _typed_client(config) as client:
            delete_api.sync_detailed(room_name=room_name, client=client)

        typer.secho(f"Room '{room_name}' deleted.", fg=typer.colors.GREEN)

        # Unregister all agents from the room in local adapter configs so the
        # plugins stop reopening SSE connections to a room that no longer exists.
        try:
            from mycelium.integrations.openclaw.dispatch import unregister_room_from_openclaw

            removed = unregister_room_from_openclaw(room_name)
            if removed:
                typer.secho(
                    f"  Unregistered {len(removed)} agent(s) from '{room_name}' in local openclaw.json.",
                    fg=typer.colors.CYAN,
                )
        except Exception:
            pass  # openclaw not installed locally — skip silently

        try:
            from mycelium.integrations.hermes.dispatch import unregister_room_from_hermes

            removed = unregister_room_from_hermes(room_name)
            if removed:
                typer.secho(
                    f"  Unregistered {len(removed)} agent(s) from '{room_name}' in local hermes config.yaml.",
                    fg=typer.colors.CYAN,
                )
        except Exception:
            pass  # hermes not installed locally — skip silently

    except Exception as e:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False
        print_error(e, verbose=verbose)


@doc_ref(
    usage="mycelium room clone <room-name> [--from <api-url>]",
    desc="Clone a room from a remote backend — fetches all memories via HTTP and writes them locally.",
    group="room",
)
@app.command("clone")
def clone_room(
    ctx: typer.Context,
    room_name: str = typer.Argument(..., help="Room name to clone"),
    from_url: str | None = typer.Option(
        None, "--from", help="Backend API URL (defaults to configured api_url)"
    ),
) -> None:
    """Clone a room from a remote backend instance via HTTP.

    Fetches all memories from the remote backend and writes them to the local
    .mycelium/rooms/ directory. Sets the room as active.

    Examples:
        mycelium room clone mycelium-dev
        mycelium room clone mycelium-dev --from http://18.216.86.206:8000
    """
    import json as _json

    import httpx

    from mycelium.filesystem import (
        ensure_room_structure,
        get_mycelium_dir,
        write_memory,
    )

    try:
        config = MyceliumConfig.load()
        api_url = from_url or config.server.api_url

        rooms_dir = get_mycelium_dir() / "rooms"
        rooms_dir.mkdir(parents=True, exist_ok=True)
        target = rooms_dir / room_name

        if target.exists():
            typer.secho(f"Room directory already exists: {target}", fg=typer.colors.RED)
            raise typer.Exit(1)

        typer.echo(f"Cloning {room_name} from {api_url}...")

        with httpx.Client(base_url=api_url, timeout=60) as client:
            resp = client.get(f"/api/rooms/{room_name}/memory", params={"limit": 1000})
            resp.raise_for_status()
            memories = resp.json()

        from datetime import datetime

        def _parse_dt(val):
            if not val or isinstance(val, datetime):
                return val
            try:
                return datetime.fromisoformat(str(val).replace("Z", "+00:00"))
            except (ValueError, AttributeError):
                return None

        ensure_room_structure(target)

        written = 0
        for mem in memories:
            value = mem.get("value", "")
            if isinstance(value, dict):
                content = value.get("text", _json.dumps(value))
            else:
                content = str(value)
            write_memory(
                target,
                mem["key"],
                content,
                created_by=mem.get("created_by"),
                updated_by=mem.get("updated_by"),
                version=mem.get("version", 1),
                tags=mem.get("tags"),
                created_at=_parse_dt(mem.get("created_at")),
                updated_at=_parse_dt(mem.get("updated_at")),
            )
            written += 1

        typer.secho(f"Cloned room: {room_name} ({written} memories)", fg=typer.colors.GREEN)

        config.rooms.active = room_name
        config.save()

        # Reindex local copy against the configured backend
        typer.echo("Re-indexing...")
        try:
            with httpx.Client(base_url=config.server.api_url, timeout=120) as client:
                resp = client.post(f"/api/rooms/{room_name}/reindex")
                resp.raise_for_status()
                data = resp.json()
            typer.echo(f"  Indexed {data.get('indexed', 0)} memories")
        except Exception:
            typer.echo(
                "[dim]  Reindex skipped — run 'mycelium memory reindex' when backend is available[/dim]"
            )

        typer.echo(f"\nRoom '{room_name}' is now active.")

    except Exception as e:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False
        print_error(e, verbose=verbose)


def _resolve_room(config: MyceliumConfig, channel: str | None = None) -> str:
    """
    Resolve the coordination room name.

    Priority:
      1. --room flag (explicit override, used as-is)
      2. MYCELIUM_ROOM_ID env var (used as-is)
      3. config.rooms.active (set via 'mycelium room use')
      4. Error
    """
    if channel:
        return channel
    room_id = os.getenv("MYCELIUM_ROOM_ID") or os.getenv("MYCELIUM_CHANNEL_ID")
    if room_id:
        return room_id
    if config.rooms.active:
        return config.rooms.active
    raise MyceliumError(
        "No room context found",
        suggestion=(
            "Pass --room <room>, set MYCELIUM_ROOM_ID in your environment, "
            "or run: mycelium room use <name>"
        ),
    )


# Known stub options for NegMAS SAO issues (mirrors options_generation.py)
_ISSUE_OPTIONS: dict[str, list[str]] = {
    "budget": ["minimal", "low", "medium", "high", "uncapped"],
    "timeline": ["express", "short", "standard", "extended", "long"],
    "scope": ["core", "standard", "extended", "full"],
    "quality": ["basic", "standard", "premium"],
}


def _render_coordination_event(msg: dict, current_identity: str) -> tuple[str | None, bool]:
    """
    Render a coordination SSE event for display.

    Returns (rendered_string | None, should_exit).
    should_exit=True means the CLI should print the message and exit.
    """
    mtype = msg.get("message_type", "")
    if not mtype:
        return None, False

    if mtype == "coordination_join":
        try:
            data = json_module.loads(msg.get("content", "{}"))
        except json_module.JSONDecodeError:
            data = {}
        handle = data.get("handle", "?")
        intent = data.get("intent")
        suffix = f" — {intent}" if intent else ""
        return f"  ⟫  {handle} joined{suffix}", False

    if mtype == "coordination_start":
        try:
            data = json_module.loads(msg.get("content", "{}"))
        except json_module.JSONDecodeError:
            data = {}
        n = data.get("agent_count", "?")
        return f"  ⟫  Session started — {n} agents joined. Beginning coordination…", False

    if mtype == "coordination_tick":
        try:
            data = json_module.loads(msg.get("content", "{}"))
        except json_module.JSONDecodeError:
            data = {}
        # SSTP envelope: action fields live under data["payload"]
        if "payload" in data and isinstance(data["payload"], dict):
            data = data["payload"]
        round_num = data.get("round", "?")
        kind = data.get("kind")

        if kind == "negotiate":
            action = data.get("action", "propose")
            participant_id = data.get("participant_id")

            # Tick not addressed to us — show informational, keep waiting
            if participant_id and participant_id != current_identity:
                return f"  ⟫  CognitiveEngine — waiting for {participant_id} ({action})…", False

            if action == "propose":
                history = data.get("history", [])
                issues: list[str] = []
                if history:
                    issues = list(history[-1].get("offer", {}).keys())
                if not issues:
                    issues = list(_ISSUE_OPTIONS.keys())
                lines = [f"  ⟫  CognitiveEngine [round {round_num}] — propose your offer:"]
                for issue in issues:
                    opts = _ISSUE_OPTIONS.get(issue, ["?"])
                    lines.append(f"        {issue}: {' | '.join(opts)}")
                example = {
                    issue: (
                        _ISSUE_OPTIONS.get(issue, ["option"])[2]
                        if len(_ISSUE_OPTIONS.get(issue, [])) > 2
                        else "option"
                    )
                    for issue in issues
                }
                lines.append("")
                kv = " ".join(f"{k}={v}" for k, v in example.items())
                lines.append(f"        Reply: mycelium negotiate propose {kv}")
                return "\n".join(lines), True

            if action == "respond":
                current_offer = data.get("current_offer") or {}
                proposer = data.get("proposer_id", "?")
                lines = [
                    f"  ⟫  CognitiveEngine [round {round_num}] — respond to offer from {proposer}:"
                ]
                for k, v in current_offer.items():
                    lines.append(f"        {k}: {v}")
                lines.append("")
                lines.append("        Accept/reject/end: mycelium negotiate respond accept")
                return "\n".join(lines), True

            return f"  ⟫  CognitiveEngine [round {round_num}] — {action} ({participant_id})", True

        # Legacy ambiguities format
        ambiguities = data.get("ambiguities", [])
        lines = [f"  ⟫  CognitiveEngine [tick {round_num}]:"]
        for i, q in enumerate(ambiguities, 1):
            lines.append(f"        {i}. {q}")
        return "\n".join(lines), True  # exit after printing

    if mtype == "coordination_consensus":
        try:
            data = json_module.loads(msg.get("content", "{}"))
        except json_module.JSONDecodeError:
            data = {}
        lines = ["  ⟫  CognitiveEngine [consensus]:"]
        if data.get("broken"):
            lines.append("        Negotiation ended without agreement.")
        else:
            assignments = data.get("assignments", {})
            assignment = assignments.get(current_identity)
            if assignment:
                lines.append(f"        Your assignment: {assignment}")
            elif assignments:
                for h, task in assignments.items():
                    lines.append(f"        {h}: {task}")
            plan = data.get("plan", "")
            if plan and not assignments:
                lines.append(f"        Plan: {plan}")
        return "\n".join(lines), True  # exit after printing

    # Regular message
    if mtype not in ("coordination_join", "coordination_start"):
        sender = msg.get("sender_handle", "?")
        content = msg.get("content", "")
        return f"  {sender}: {content}", False

    return None, False


def _watch_room(config: MyceliumConfig, room_name: str, timeout: int) -> None:
    """Core SSE watch loop — pretty-renders coordination and memory events."""
    import time

    import httpx
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text

    console = Console()

    def ts() -> str:
        return f"[dim]{time.strftime('%H:%M:%S')}[/]"

    def render(msg: dict) -> str | None:
        mtype = msg.get("message_type", "") or msg.get("type", "")
        sender = msg.get("sender_handle", msg.get("updated_by", "?"))

        try:
            data = (
                json_module.loads(msg.get("content", "{}"))
                if isinstance(msg.get("content"), str)
                else msg
            )
        except (json_module.JSONDecodeError, TypeError):
            data = msg

        if mtype == "coordination_join":
            intent = data.get("intent")
            handle = data.get("handle", sender)
            suffix = f" — [dim]{intent}[/]" if intent else ""
            return f"  {ts()}  [cyan]{handle}[/] joined{suffix}"

        if mtype == "coordination_start":
            n = data.get("agent_count", "?")
            return f"\n  {ts()}  [bold cyan]session started[/] — {n} agents joined\n"

        if mtype == "coordination_tick":
            # SSTP envelope: action fields live under data["payload"]
            if "payload" in data and isinstance(data["payload"], dict):
                data = data["payload"]
            round_num = data.get("round", "?")
            kind = data.get("kind")
            if kind == "negotiate":
                action = data.get("action", "propose")
                participant = data.get("participant_id", "?")
                if action == "propose":
                    issue_options = data.get("issue_options") or _ISSUE_OPTIONS
                    header = f"\n  {ts()}  [bold magenta]CognitiveEngine[/] [dim]→[/] [cyan]{participant}[/]  [bold cyan]round {round_num}[/] — propose your offer:"
                    if round_num == 1:
                        header = f"\n  {ts()}  [bold magenta]CognitiveEngine[/] analyzed agent intents and generated negotiation issues and options.\n{header}"
                    lines = [header]
                    for k, v in issue_options.items():
                        lines.append(f"              [bold white]{k}[/]")
                        opts = v if isinstance(v, list) else [str(v)]
                        for i, opt in enumerate(opts, 1):
                            lines.append(f"                [dim]{i}.[/] {opt}")
                    return "\n".join(lines)
                if action == "respond":
                    offer = data.get("current_offer") or {}
                    proposer = data.get("proposer_id", "?")
                    lines = [
                        f"\n  {ts()}  [bold magenta]CognitiveEngine[/] [dim]→[/] [cyan]{participant}[/]  [bold cyan]round {round_num}[/] — respond to offer from {proposer}:"
                    ]
                    for k, v in offer.items():
                        lines.append(f"              [dim]{k}:[/] {v}")
                    return "\n".join(lines)
                return f"\n  {ts()}  [bold magenta]CognitiveEngine[/] [dim]→[/] [cyan]{participant}[/]  [bold cyan]round {round_num}[/] — {action}"
            return f"\n  {ts()}  [bold cyan]tick {round_num}[/]"

        if mtype == "coordination_consensus":
            plan = data.get("plan", "")
            assignments = data.get("assignments", {})
            lines = [f"\n  {ts()}  [bold green]consensus[/]"]
            if plan:
                lines.append(f"              [dim]plan:[/] {plan}")
            for handle, task in assignments.items():
                lines.append(f"              [cyan]{handle}[/]: {task}")
            return "\n".join(lines)

        if mtype == "memory_changed":
            key = data.get("key", "?")
            version = data.get("version", "?")
            by = data.get("updated_by", "?")
            return f"  {ts()}  [yellow]memory[/] [dim]{key}[/] v{version} by {by}"

        if mtype == "synthesis_complete":
            skey = data.get("synthesis_key", "?")
            return f"  {ts()}  [bold green]synthesis[/] → {skey}"

        if mtype == "delegate":
            recipient = msg.get("recipient_handle", "?")
            content = msg.get("content", "")
            return f"  {ts()}  [magenta]{sender}[/] [dim]→[/] [cyan]{recipient}[/]: {content}"

        if mtype in ("direct", "broadcast", "announce"):
            content = msg.get("content", "")
            color = "yellow" if mtype == "broadcast" else "blue"
            return f"  {ts()}  [{color}]{sender}[/]: {content}"

        return None

    room_meta = ""

    # Header
    header = Table.grid(padding=(0, 2))
    header.add_row(
        Text(room_name, style="bold cyan"),
        Text("Ctrl+C to stop", style="dim"),
    )
    console.print()
    console.print(
        Panel(
            f"[bold]{room_name}[/]\n{room_meta}" if room_meta else f"[bold]{room_name}[/]",
            title="[dim]watching[/]",
            border_style="dim",
            width=60,
            padding=(0, 2),
        )
    )

    # Replay recent history so events that fired before SSE connected are visible.
    # coordination_join events are NOTIFY-only (not persisted), so we synthesize
    # them from the sessions list to ensure all participants are shown.
    try:
        sess_resp = httpx.get(
            f"{config.server.api_url}/api/rooms/{room_name}/sessions",
            timeout=10,
        )
        if sess_resp.status_code == 200:
            sess_body = sess_resp.json()
            participants = sess_body.get("sessions", [])
            for p in participants:
                rendered = render(
                    {
                        "message_type": "coordination_join",
                        "sender_handle": p.get("agent_handle", "?"),
                        "content": json_module.dumps(
                            {
                                "handle": p.get("agent_handle"),
                                "intent": p.get("intent"),
                            }
                        ),
                    }
                )
                if rendered:
                    console.print(rendered, highlight=False)
    except Exception:
        pass

    try:
        hist_resp = httpx.get(
            f"{config.server.api_url}/api/rooms/{room_name}/messages",
            params={"limit": 50},
            timeout=10,
        )
        if hist_resp.status_code == 200:
            body = hist_resp.json()
            msgs = body.get("messages", body) if isinstance(body, dict) else body
            for msg in reversed(msgs):
                rendered = render(msg)
                if rendered:
                    console.print(rendered, highlight=False)
    except Exception:
        pass

    url = f"{config.server.api_url}/api/rooms/{room_name}/messages/stream"
    start = time.time()

    with httpx.Client(timeout=None) as http, http.stream("GET", url) as response:
        for line in response.iter_lines():
            if timeout > 0 and (time.time() - start) >= timeout:
                console.print(f"\n  [dim]Timeout after {timeout}s[/]")
                return
            line = line.strip()
            if not line or line.startswith(":"):
                continue
            if line.startswith("data:"):
                payload = line[5:].strip()
                try:
                    msg = json_module.loads(payload)
                except json_module.JSONDecodeError:
                    continue
                rendered = render(msg)
                if rendered:
                    console.print(rendered, highlight=False)


@doc_ref(
    usage="mycelium watch [room]",
    desc="Stream live room activity via SSE. Messages appear in real time as other agents write.",
    group="other",
)
@app.command()
def watch(
    ctx: typer.Context,
    room_name: str | None = typer.Argument(None, help="Room to watch (default: active room)"),
    timeout: int = typer.Option(0, "--timeout", "-t", help="Timeout in seconds (0=no timeout)"),
) -> None:
    """
    Stream live messages from a room.

    Auto-resolves the active room — no argument needed.
    Renders coordination events, agent joins, ticks, and consensus.

    Examples:
        mycelium room watch
        mycelium room watch my-room
        mycelium room watch --timeout 120
    """
    try:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False  # noqa: F841
        config = MyceliumConfig.load()
        name = room_name or _resolve_room(config)
        _watch_room(config, name, timeout)
    except KeyboardInterrupt:
        typer.echo("\n  [Stopped]")
    except Exception as e:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False
        print_error(e, verbose=verbose)


@doc_ref(
    usage="mycelium room post <room> --agent <handle> --response <text>",
    desc="Post a raw message to a room (triggers NOTIFY). Advanced use.",
    group="room",
)
@app.command("post")
def post(
    ctx: typer.Context,
    session_id: str = typer.Argument(..., help="Room session/name"),
    agent: str = typer.Option(..., "--agent", "-a", help="Agent handle sending the response"),
    response_text: str = typer.Option(..., "--response", "-r", help="Response message text"),
) -> None:
    """
    Post a message to a room (triggers NOTIFY).

    Examples:
        mycelium room post my-room --agent alpha#a1b2 --response "Task complete"
    """
    try:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False  # noqa: F841
        json_output = ctx.obj.get("json", False) if ctx.obj else False

        config = MyceliumConfig.load()

        from mycelium_backend_client.api.messages import (
            send_message_api_rooms_room_name_messages_post as send_api,
        )
        from mycelium_backend_client.models import MessageCreate

        with _typed_client(config) as client:
            body = MessageCreate(sender_handle=agent, message_type="direct", content=response_text)
            result = send_api.sync(room_name=session_id, client=client, body=body)
            data = result.to_dict() if result and hasattr(result, "to_dict") else {}

        if json_output:
            typer.echo(json_module.dumps(data, indent=2, default=str))
        else:
            typer.secho("Message sent", fg=typer.colors.GREEN)
            typer.echo(f"  {agent}: {response_text[:80]}")

    except Exception as e:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False
        print_error(e, verbose=verbose)


@doc_ref(
    usage='mycelium room send "<content>" [--room <room>] [--handle <handle>]',
    desc="Send an addressed chat message into a room. Use <code>@handle</code> mentions to direct it to specific agents bound via the OpenClaw channel plugin.",
    group="room",
)
@app.command("send")
def send(
    ctx: typer.Context,
    content: str = typer.Argument(
        ...,
        help='Message content. Use @handle mentions to address specific agents, e.g. "@julia-agent ping".',
    ),
    room: str | None = typer.Option(
        None, "--room", "-r", help="Room to post into (defaults to active room)"
    ),
    handle: str | None = typer.Option(
        None,
        "--handle",
        "-H",
        help="Your sender handle (defaults to identity config)",
    ),
) -> None:
    """
    Send an addressed chat message into a room (cross-agent DM).

    Drops a broadcast message into the room's message stream. Agents bound
    to the room via the OpenClaw channel plugin will receive it if the
    content @-mentions them (when `requireMention` is enabled, default true).

    Use this for:
      - Addressed DMs between agents in the same room
      - Seeding a scenario for a group of agents (facilitator posts, agents respond)
      - One-way notifications without expecting a reply loop

    For structured negotiation (propose/accept/reject), use `mycelium negotiate
    propose|respond` instead. For agent-to-agent requests with a built-in
    reply loop, use OpenClaw's `sessions_send` tool.

    Examples:
        mycelium room send "@julia-agent please review the cache config"
        mycelium room send --room design-review --handle arnold "@selina-agent thoughts on the API proposal?"
        mycelium room send "@julia-agent @selina-agent sync at 3pm re: sprint priorities"
    """
    try:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False  # noqa: F841
        json_output = ctx.obj.get("json", False) if ctx.obj else False

        config = MyceliumConfig.load()
        room_name = _resolve_room(config, room)
        sender_handle = handle or config.get_current_identity()

        from mycelium_backend_client.api.messages import (
            send_message_api_rooms_room_name_messages_post as send_api,
        )
        from mycelium_backend_client.models import MessageCreate

        with _typed_client(config) as client:
            body = MessageCreate(
                sender_handle=sender_handle,
                message_type="broadcast",
                content=content,
            )
            result = send_api.sync(room_name=room_name, client=client, body=body)

        if json_output and result:
            msg_dict = result.to_dict() if hasattr(result, "to_dict") else str(result)
            typer.echo(json_module.dumps(msg_dict, indent=2, default=str))
            return

        preview = content[:80] + ("…" if len(content) > 80 else "")
        typer.echo(f"  ↑  {sender_handle} → {room_name}: {preview}")

    except (typer.Exit, typer.Abort):
        raise
    except Exception as e:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False
        print_error(e, verbose=verbose)


@doc_ref(
    usage="mycelium room messages [<room>] [--limit N] [--sender <handle>] [--type <type>]",
    desc="Read recent messages in a room (point-in-time, newest first). Filter with <code>--sender</code> / <code>--type</code>.",
    group="room",
)
@app.command("messages")
def messages(
    ctx: typer.Context,
    room: str | None = typer.Argument(None, help="Room to read (defaults to active room)"),
    limit: int = typer.Option(20, "--limit", "-l", help="Max messages to show (newest first)"),
    sender: str | None = typer.Option(
        None, "--sender", "-s", help="Only messages from this handle"
    ),
    message_type: str | None = typer.Option(
        None, "--type", "-t", help="Only this message type (e.g. direct, broadcast, announce)"
    ),
) -> None:
    """
    Read recent messages in a room — a point-in-time snapshot, newest first.

    Unlike `mycelium room watch` (which streams live), this returns immediately
    with the most recent messages and exits. Handy for scripts and for checking
    whether an agent's reply has landed.

    Examples:
        mycelium room messages
        mycelium room messages design-review --limit 5
        mycelium room messages cc-e2e --sender cc-x
        mycelium room messages my-room --type broadcast
    """
    try:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False  # noqa: F841
        json_output = ctx.obj.get("json", False) if ctx.obj else False

        config = MyceliumConfig.load()
        room_name = _resolve_room(config, room)

        from mycelium_backend_client.api.messages import (
            list_messages_api_rooms_room_name_messages_get as list_api,
        )
        from mycelium_backend_client.models import HTTPValidationError
        from mycelium_backend_client.types import UNSET

        with _typed_client(config) as client:
            result = list_api.sync(
                room_name=room_name,
                client=client,
                limit=limit,
                sender=sender or UNSET,
                message_type=message_type or UNSET,
            )

        if not result or isinstance(result, HTTPValidationError):
            msgs = []
        else:
            msgs = result.messages

        if json_output:
            payload = (
                result.to_dict()
                if result and not isinstance(result, HTTPValidationError)
                else {"messages": [], "total": 0}
            )
            typer.echo(json_module.dumps(payload, indent=2, default=str))
            return

        if not msgs:
            typer.echo(f"  {room_name}: no messages")
            return

        plural = "message" if len(msgs) == 1 else "messages"
        typer.secho(f"\n  {room_name}  ", fg=typer.colors.CYAN, bold=True, nl=False)
        typer.secho(f"({len(msgs)} {plural}, newest first)\n", fg=typer.colors.BRIGHT_BLACK)
        for m in msgs:
            stamp = m.created_at.strftime("%H:%M:%S")
            content = m.content.replace("\n", " ")
            preview = content[:100] + ("…" if len(content) > 100 else "")
            typer.echo(f"  {stamp}  {m.sender_handle} [{m.message_type}]: {preview}")
        typer.echo()

    except (typer.Exit, typer.Abort):
        raise
    except Exception as e:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False
        print_error(e, verbose=verbose)


@doc_ref(
    usage="mycelium room delegate <room> --to <handle> --task <description>",
    desc="Delegate a task to another agent in a room.",
    group="room",
)
@app.command()
def delegate(
    ctx: typer.Context,
    session_id: str = typer.Argument(..., help="Room session/name"),
    to: str = typer.Option(..., "--to", help="Target agent handle"),
    task: str = typer.Option(..., "--task", "-t", help="Task description to delegate"),
) -> None:
    """
    Delegate a task to an agent in a room.

    Posts a 'delegate' type message to the room.

    Examples:
        mycelium room delegate my-room --to cfn-agent --task "Scan CVE-2024-1234"
    """
    try:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False  # noqa: F841
        json_output = ctx.obj.get("json", False) if ctx.obj else False

        config = MyceliumConfig.load()
        sender = config.get_current_identity()

        from mycelium_backend_client.api.messages import (
            send_message_api_rooms_room_name_messages_post as send_api,
        )
        from mycelium_backend_client.models import MessageCreate

        with _typed_client(config) as client:
            body = MessageCreate(
                sender_handle=sender, message_type="delegate", content=task, recipient_handle=to
            )
            result = send_api.sync(room_name=session_id, client=client, body=body)
            data = result.to_dict() if result and hasattr(result, "to_dict") else {}

        if json_output:
            typer.echo(json_module.dumps(data, indent=2, default=str))
        else:
            typer.secho("Task delegated", fg=typer.colors.GREEN)
            typer.echo(f"  {sender} -> {to}: {task[:80]}")

    except Exception as e:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False
        print_error(e, verbose=verbose)


@doc_ref(
    usage="mycelium room sync-mas <name>",
    desc="Register (or re-register) a room with the CFN mgmt plane.",
    group="room",
)
@app.command("sync-mas")
def sync_mas(
    ctx: typer.Context,
    name: str = typer.Argument(..., help="Room name to register with CFN"),
) -> None:
    """Register a room with the CFN mgmt plane and store its MAS ID.

    Idempotent: if the room is already registered in CFN, the existing MAS ID
    is fetched and linked. Use this to fix rooms created before CFN was configured
    or when 'mycelium doctor' reports missing MAS IDs.

    Examples:
        mycelium room sync-mas mycelium_room
        mycelium room sync-mas matrix-agents
    """
    try:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False  # noqa: F841
        json_output = ctx.obj.get("json", False) if ctx.obj else False

        config = MyceliumConfig.load()

        import httpx

        api_url = (config.server.api_url or "http://localhost:8000").rstrip("/")
        with httpx.Client(base_url=api_url, timeout=15) as client:
            resp = client.post(f"/api/rooms/{name}/sync-mas")
            if resp.status_code == 404:
                raise MyceliumError(
                    f"Room '{name}' not found — create it first with: mycelium room create {name}"
                )
            if resp.status_code == 409:
                raise MyceliumError(
                    "CFN not configured — set CFN_MGMT_URL and WORKSPACE_ID in ~/.mycelium/.env"
                )
            resp.raise_for_status()
            room_data = resp.json()

        if json_output:
            typer.echo(json_module.dumps(room_data, indent=2, default=str))
        else:
            typer.secho(f"Registered room with CFN: {name}", fg=typer.colors.GREEN)
            typer.echo(f"  MAS ID:  {room_data.get('mas_id')}")
            typer.echo(f"  Workspace: {room_data.get('workspace_id')}")

    except MyceliumError:
        raise
    except Exception as e:
        verbose = ctx.obj.get("verbose", False) if ctx.obj else False
        print_error(e, verbose=verbose)
