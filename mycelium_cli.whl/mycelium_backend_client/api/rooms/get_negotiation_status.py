from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_negotiation_status_response_get_negotiation_status import (
    GetNegotiationStatusResponseGetNegotiationStatus,
)
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    room_name: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/rooms/{room_name}/negotiation".format(
            room_name=quote(str(room_name), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetNegotiationStatusResponseGetNegotiationStatus | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = GetNegotiationStatusResponseGetNegotiationStatus.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetNegotiationStatusResponseGetNegotiationStatus | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    room_name: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[GetNegotiationStatusResponseGetNegotiationStatus | HTTPValidationError]:
    r"""Get Negotiation Status

     Return live negotiation state for an active session room.

    Returns ``{\"active\": false}`` when no negotiation is in progress.
    ``pending_replies`` values are ``\"received\"`` or ``\"waiting\"``.

    Args:
        room_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetNegotiationStatusResponseGetNegotiationStatus | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        room_name=room_name,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    room_name: str,
    *,
    client: AuthenticatedClient | Client,
) -> GetNegotiationStatusResponseGetNegotiationStatus | HTTPValidationError | None:
    r"""Get Negotiation Status

     Return live negotiation state for an active session room.

    Returns ``{\"active\": false}`` when no negotiation is in progress.
    ``pending_replies`` values are ``\"received\"`` or ``\"waiting\"``.

    Args:
        room_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetNegotiationStatusResponseGetNegotiationStatus | HTTPValidationError
    """

    return sync_detailed(
        room_name=room_name,
        client=client,
    ).parsed


async def asyncio_detailed(
    room_name: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[GetNegotiationStatusResponseGetNegotiationStatus | HTTPValidationError]:
    r"""Get Negotiation Status

     Return live negotiation state for an active session room.

    Returns ``{\"active\": false}`` when no negotiation is in progress.
    ``pending_replies`` values are ``\"received\"`` or ``\"waiting\"``.

    Args:
        room_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetNegotiationStatusResponseGetNegotiationStatus | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        room_name=room_name,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    room_name: str,
    *,
    client: AuthenticatedClient | Client,
) -> GetNegotiationStatusResponseGetNegotiationStatus | HTTPValidationError | None:
    r"""Get Negotiation Status

     Return live negotiation state for an active session room.

    Returns ``{\"active\": false}`` when no negotiation is in progress.
    ``pending_replies`` values are ``\"received\"`` or ``\"waiting\"``.

    Args:
        room_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetNegotiationStatusResponseGetNegotiationStatus | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            room_name=room_name,
            client=client,
        )
    ).parsed
